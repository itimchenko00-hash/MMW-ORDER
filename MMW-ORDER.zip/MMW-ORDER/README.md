# MMW-ORDER

Independent technical order-entry application. It does **not** depend on or write to MMW-COMPANY repositories.

## Stack
- Node.js 20 + Express 5
- Vanilla HTML/CSS/JS frontend
- SQLite locally / PostgreSQL when `DATABASE_URL` is provided
- Resend email delivery
- Telegram Bot API notifications
- Render-ready deployment

## Run locally
```bash
cp .env.example .env
npm install
npm start
```
Open `http://localhost:3000`.

## Render
Create a PostgreSQL database and set `DATABASE_URL`, then deploy this repository as a Web Service. Add the Resend and Telegram environment variables. `render.yaml` is included.

## Security
Secrets are server-side only. The browser never receives Resend or Telegram credentials. Client request history is scoped by a random access token returned only after successful order creation and stored locally in the browser.
