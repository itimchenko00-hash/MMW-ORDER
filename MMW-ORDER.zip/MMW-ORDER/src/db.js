import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import pg from 'pg';
import { catalog } from './catalog.js';
const { Pool }=pg;
const usePg=Boolean(process.env.DATABASE_URL);
const localFile=path.resolve('.data/orders.json');
let pool;
async function init(){
 if(usePg){pool=new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL.includes('localhost')?false:{rejectUnauthorized:false}});await pool.query(`CREATE TABLE IF NOT EXISTS orders (id TEXT PRIMARY KEY, access_token TEXT NOT NULL, created_at TIMESTAMPTZ NOT NULL, status TEXT NOT NULL, customer_name TEXT NOT NULL, phone TEXT NOT NULL, email TEXT NOT NULL, company TEXT DEFAULT '', project_type TEXT DEFAULT '', address TEXT DEFAULT '', comment TEXT DEFAULT '', items_json JSONB NOT NULL, total INTEGER NOT NULL)`)}
 else {fs.mkdirSync(path.dirname(localFile),{recursive:true});if(!fs.existsSync(localFile))fs.writeFileSync(localFile,'[]')}
}
export const ready=init();
function readLocal(){return JSON.parse(fs.readFileSync(localFile,'utf8'))}
function writeLocal(rows){fs.writeFileSync(localFile,JSON.stringify(rows,null,2))}
export async function createOrder(payload){await ready;const id=`MMW-${new Date().toISOString().slice(0,10).replaceAll('-','')}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,accessToken=crypto.randomBytes(24).toString('hex'),items=normalizeItems(payload.items),total=items.reduce((s,i)=>s+i.price*i.qty,0),createdAt=new Date().toISOString();const row={id,accessToken,createdAt,status:'Новая',...payload,items,total};if(usePg)await pool.query(`INSERT INTO orders VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13)`,[id,accessToken,createdAt,'Новая',payload.customerName,payload.phone,payload.email,payload.company,payload.projectType,payload.address,payload.comment,JSON.stringify(items),total]);else{const rows=readLocal();rows.push(row);writeLocal(rows)}return row}
export async function listOrders(token){await ready;let rows;if(usePg)rows=(await pool.query('SELECT * FROM orders WHERE access_token=$1 ORDER BY created_at DESC',[token])).rows;else rows=readLocal().filter(r=>r.accessToken===token).sort((a,b)=>b.createdAt.localeCompare(a.createdAt));return rows.map(r=>({id:r.id,createdAt:r.created_at||r.createdAt,status:r.status,customerName:r.customer_name||r.customerName,items:typeof r.items_json==='string'?JSON.parse(r.items_json):r.items_json||r.items,total:r.total}))}
function normalizeItems(items=[]){const allowed=new Map([...catalog.packages.map(x=>[x.id,x]),...catalog.services.map(x=>[x.id,x])]);return items.filter(x=>allowed.has(x.id)).map(x=>({id:x.id,name:allowed.get(x.id).name,price:allowed.get(x.id).price,qty:Math.max(1,Math.min(99,Number(x.qty)||1)),kind:catalog.packages.some(p=>p.id===x.id)?'package':'service'}))}
