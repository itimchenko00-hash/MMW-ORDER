import express from 'express';
import helmet from 'helmet';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { catalog } from './catalog.js';
import { createOrder, listOrders } from './db.js';
import { notifyOrder } from './notifications.js';

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express();
app.use(helmet({contentSecurityPolicy:false}));
app.use(express.json({limit:'100kb'}));
app.use(express.static(path.join(__dirname,'../public')));
app.get('/api/health',(req,res)=>res.json({ok:true,app:'MMW-ORDER'}));
app.get('/api/catalog',(req,res)=>res.json(catalog));
app.get('/api/orders',async(req,res)=>{
  const token=String(req.query.token||'');
  if(!/^[a-f0-9]{48}$/.test(token)) return res.status(400).json({error:'Некорректный токен'});
  res.json({orders:await listOrders(token)});
});
app.post('/api/orders',async(req,res)=>{
  try {
    const p=req.body||{};
    if(!p.customerName?.trim()||!p.phone?.trim()||!p.email?.trim()||!Array.isArray(p.items)||!p.items.length) return res.status(400).json({error:'Заполните имя, телефон, email и добавьте хотя бы одну позицию.'});
    if(!/^\S+@\S+\.\S+$/.test(p.email)) return res.status(400).json({error:'Проверьте email.'});
    const order=await createOrder({customerName:p.customerName.trim().slice(0,120),phone:p.phone.trim().slice(0,40),email:p.email.trim().slice(0,160),company:String(p.company||'').trim().slice(0,160),projectType:String(p.projectType||'').trim().slice(0,100),address:String(p.address||'').trim().slice(0,300),comment:String(p.comment||'').trim().slice(0,2000),items:p.items});
    const notifications=await notifyOrder(order);
    res.status(201).json({order:{id:order.id,createdAt:order.createdAt,status:order.status,total:order.total,items:order.items},accessToken:order.accessToken,notifications});
  } catch(e){console.error(e);res.status(500).json({error:'Не удалось создать заявку.'});}
});
app.listen(process.env.PORT||3000,()=>console.log(`MMW-ORDER listening on ${process.env.PORT||3000}`));
