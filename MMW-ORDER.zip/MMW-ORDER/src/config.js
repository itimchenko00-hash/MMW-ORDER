export const config = {
  port: Number(process.env.PORT || 3000),
  appName: process.env.APP_NAME || 'MMW-ORDER',
  publicBaseUrl: process.env.PUBLIC_BASE_URL || 'http://localhost:3000',
  adminEmail: process.env.ADMIN_EMAIL || 'itimchenko00@gmail.com',
  resendApiKey: process.env.RESEND_API_KEY || '',
  resendFrom: process.env.RESEND_FROM || '',
  telegramBotToken: process.env.TELEGRAM_BOT_TOKEN || '',
  telegramChatId: process.env.TELEGRAM_CHAT_ID || '',
  databaseUrl: process.env.DATABASE_URL || ''
};
