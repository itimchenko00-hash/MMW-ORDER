import { Resend } from 'resend';
import { config } from './config.js';

export async function notifyOrder(order) {
  const results = { email:false, telegram:false };
  const lines = order.items.map(i=>`• ${i.name} × ${i.qty} — ${formatUAH(i.price*i.qty)}`).join('\n');
  const subject = `Новая заявка ${order.id} — ${order.customerName}`;
  const text = `Новая заявка ${order.id}\n\nКлиент: ${order.customerName}\nТелефон: ${order.phone}\nEmail: ${order.email}\nКомпания: ${order.company || '—'}\nТип проекта: ${order.projectType || '—'}\nАдрес: ${order.address || '—'}\n\nПозиции:\n${lines}\n\nИТОГО: ${formatUAH(order.total)}\n\nКомментарий:\n${order.comment || '—'}`;

  if (config.resendApiKey && config.resendFrom && config.adminEmail) {
    try { const resend = new Resend(config.resendApiKey); await resend.emails.send({from:config.resendFrom,to:[config.adminEmail],subject,text}); results.email=true; } catch(e){ console.error('Resend error:',e.message); }
  }
  if (config.telegramBotToken && config.telegramChatId) {
    try { const url=`https://api.telegram.org/bot${config.telegramBotToken}/sendMessage`; const r=await fetch(url,{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({chat_id:config.telegramChatId,text})}); results.telegram=r.ok; } catch(e){ console.error('Telegram error:',e.message); }
  }
  return results;
}
export const formatUAH = n => new Intl.NumberFormat('uk-UA',{style:'currency',currency:'UAH',maximumFractionDigits:0}).format(n);
